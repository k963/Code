﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelToXML.Helper
{
    class ConvertToXML
    {
        public string getXMLData(string fileName)
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkbook = null;
            Helper helper = new Helper();
            //helper.OpenExcel(fileName);
            if (helper.Checkfileforread(fileName))
            {
                //COM Objects. Create a COM object for everything that is referenced
                xlApp = new Excel.Application();
                xlWorkbook = xlApp.Workbooks.Open(fileName);
            }
            foreach (Excel.Worksheet xlWorksheet in xlWorkbook.Worksheets)
            {
                //xlworksheet code here
            Excel.Range xlRange = xlWorksheet.UsedRange;
                int rows = xlWorksheet.Rows.Count;
                int coloumn = xlWorksheet.Columns.Count;
            }


            //helper.CloseExcel(fileName);
            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);


            return "";
        }
    }
}
