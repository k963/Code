﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;


namespace ExcelToXML.Helper
{
    class Helper
    {
        public void OpenExcel(string fileName)
        {
            
        }

        internal bool Checkfileforread(string filename)
        {

            try
            {
                FileStream fs =  new FileStream(filename, FileMode.Open);
                fs.Close();
                return true;
            }
            catch (IOException)
            {
                foreach (var process in Process.GetProcessesByName("excel")) //excel application needs to be closed
                {
                    if (process.MainWindowTitle.Contains(filename))
                    {
                        process.Kill();
                        break;
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public void CloseExcel(string FileName)
        {



        }
    }
}
