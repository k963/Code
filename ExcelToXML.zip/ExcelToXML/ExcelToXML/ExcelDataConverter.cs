﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExcelToXML.Helper;

namespace ExcelToXML
{
    public partial class ExcelDataConverter : Form
    {
        public ExcelDataConverter()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openfileDialog = new OpenFileDialog())
            {
                openfileDialog.RestoreDirectory = true;
                openfileDialog.Filter = "Excel files(*.xlsx;*.xls)|*.xlsx;*.xls";

                if (openfileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtbxFileName.Text = openfileDialog.FileName;
                }
            }
            string fileName = txtbxFileName.Text;

            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName))
            {
                MessageBox.Show("The Excel file is invalid! Please select a valid file.");
                return;
            }

            try
            {
                ConvertToXML convertToXML = new ConvertToXML();
                string xmlFormatstring = convertToXML.getXMLData(fileName);
                ///string xmlFormatstring = new ConvertExcelToXml().GetXML(excelfileName);
                if (string.IsNullOrEmpty(xmlFormatstring))
                {
                    MessageBox.Show("The content of Excel file is Empty!");
                    return;
                }

                ///txtbxData.Text = xmlFormatstring.Replace("_x0020_", "");

                // If txbXmlView has text, set btnSaveAs button to be enable
                ///btnSaveAs.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurs! The error message is: " + ex.Message);
            }

        }

        private void btnConvertToXml_Click(object sender, EventArgs e)
        {


        }
    }
}
