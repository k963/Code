﻿namespace ExcelToXML
{
    partial class ExcelDataConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUploadFile = new System.Windows.Forms.Button();
            this.txtbxData = new System.Windows.Forms.RichTextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtbxFileName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnUploadFile
            // 
            this.btnUploadFile.Location = new System.Drawing.Point(365, 10);
            this.btnUploadFile.Name = "btnUploadFile";
            this.btnUploadFile.Size = new System.Drawing.Size(120, 23);
            this.btnUploadFile.TabIndex = 0;
            this.btnUploadFile.Text = "Uplaod File";
            this.btnUploadFile.UseVisualStyleBackColor = true;
            this.btnUploadFile.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // txtbxData
            // 
            this.txtbxData.Location = new System.Drawing.Point(12, 62);
            this.txtbxData.Name = "txtbxData";
            this.txtbxData.Size = new System.Drawing.Size(473, 174);
            this.txtbxData.TabIndex = 4;
            this.txtbxData.Text = "";
            this.txtbxData.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // txtbxFileName
            // 
            this.txtbxFileName.Location = new System.Drawing.Point(12, 12);
            this.txtbxFileName.Name = "txtbxFileName";
            this.txtbxFileName.Size = new System.Drawing.Size(329, 20);
            this.txtbxFileName.TabIndex = 1;
            // 
            // ExcelDataConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 322);
            this.Controls.Add(this.txtbxData);
            this.Controls.Add(this.txtbxFileName);
            this.Controls.Add(this.btnUploadFile);
            this.Name = "ExcelDataConverter";
            this.Text = "Excel to XML";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUploadFile;
        private System.Windows.Forms.RichTextBox txtbxData;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtbxFileName;
    }
}

